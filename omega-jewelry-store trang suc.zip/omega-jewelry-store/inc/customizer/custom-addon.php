<?php
/**
* Custom Addons.
*
* @package Omega Jewelry Store
*/

$wp_customize->add_section( 'omega_jewelry_store_theme_pagination_options',
    array(
    'title'      => esc_html__( 'Customizer Custom Settings', 'omega-jewelry-store' ),
    'priority'   => 10,
    'capability' => 'edit_theme_options',
    'panel'      => 'omega_jewelry_store_theme_addons_panel',
    )
);

$wp_customize->add_setting( 'omega_jewelry_store_theme_pagination_options_alignment',
    array(
    'capability'        => 'edit_theme_options',
    'sanitize_callback' => 'omega_jewelry_store_sanitize_pagination_meta',
    )
);
$wp_customize->add_control( 'omega_jewelry_store_theme_pagination_options_alignment',
    array(
    'label'       => esc_html__( 'Pagination Alignment', 'omega-jewelry-store' ),
    'section'     => 'omega_jewelry_store_theme_pagination_options',
    'type'        => 'select',
    'choices'     => array(
        'Center'    => esc_html__( 'Center', 'omega-jewelry-store' ),
        'Right' => esc_html__( 'Right', 'omega-jewelry-store' ),
        'Left'  => esc_html__( 'Left', 'omega-jewelry-store' ),
        ),
    )
);

$wp_customize->add_setting( 'omega_jewelry_store_theme_breadcrumb_options_alignment',
    array(
    'capability'        => 'edit_theme_options',
    'sanitize_callback' => 'omega_jewelry_store_sanitize_pagination_meta',
    )
);
$wp_customize->add_control( 'omega_jewelry_store_theme_breadcrumb_options_alignment',
    array(
    'label'       => esc_html__( 'Breadcrumb Alignment', 'omega-jewelry-store' ),
    'section'     => 'omega_jewelry_store_theme_pagination_options',
    'type'        => 'select',
    'choices'     => array(
        'Center'    => esc_html__( 'Center', 'omega-jewelry-store' ),
        'Right' => esc_html__( 'Right', 'omega-jewelry-store' ),
        'Left'  => esc_html__( 'Left', 'omega-jewelry-store' ),
        ),
    )
);