<?php
/**
* Header Options.
*
* @package Omega Jewelry Store
*/

$omega_jewelry_store_default = omega_jewelry_store_get_default_theme_options();

// Header Section.
$wp_customize->add_section( 'omega_jewelry_store_button_header_setting',
	array(
	'title'      => esc_html__( 'Header Settings', 'omega-jewelry-store' ),
	'priority'   => 10,
	'capability' => 'edit_theme_options',
	'panel'      => 'omega_jewelry_store_theme_option_panel',
	)
);

$wp_customize->add_setting( 'omega_jewelry_store_header_layout_20_per_discount_text',
    array(
    'default'           => $omega_jewelry_store_default['omega_jewelry_store_header_layout_20_per_discount_text'],
    'capability'        => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control( 'omega_jewelry_store_header_layout_20_per_discount_text',
    array(
    'label'    => esc_html__( 'Header Shipping Text', 'omega-jewelry-store' ),
    'section'  => 'omega_jewelry_store_button_header_setting',
    'type'     => 'text',
    )
);

$wp_customize->add_setting( 'omega_jewelry_store_header_layout_email_address',
    array(
    'default'           => $omega_jewelry_store_default['omega_jewelry_store_header_layout_email_address'],
    'capability'        => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control( 'omega_jewelry_store_header_layout_email_address',
    array(
    'label'    => esc_html__( 'Header Email Address', 'omega-jewelry-store' ),
    'section'  => 'omega_jewelry_store_button_header_setting',
    'type'     => 'text',
    )
);

$wp_customize->add_setting('omega_jewelry_store_header_layout_enable_translator',
    array(
        'default' => $omega_jewelry_store_default['omega_jewelry_store_header_layout_enable_translator'],
        'capability' => 'edit_theme_options',
        'sanitize_callback' => 'omega_jewelry_store_sanitize_checkbox',
    )
);
$wp_customize->add_control('omega_jewelry_store_header_layout_enable_translator',
    array(
        'label' => esc_html__('Enable Google Translator', 'omega-jewelry-store'),
        'section' => 'omega_jewelry_store_button_header_setting',
        'type' => 'checkbox',
    )
);

$wp_customize->add_setting('omega_jewelry_store_sticky',
    array(
        'default' => $omega_jewelry_store_default['omega_jewelry_store_sticky'],
        'capability' => 'edit_theme_options',
        'sanitize_callback' => 'omega_jewelry_store_sanitize_checkbox',
    )
);
$wp_customize->add_control('omega_jewelry_store_sticky',
    array(
        'label' => esc_html__('Enable Sticky Header', 'omega-jewelry-store'),
        'section' => 'omega_jewelry_store_button_header_setting',
        'type' => 'checkbox',
    )
);

$wp_customize->add_setting('omega_jewelry_store_theme_loader',
    array(
        'default' => $omega_jewelry_store_default['omega_jewelry_store_theme_loader'],
        'capability' => 'edit_theme_options',
        'sanitize_callback' => 'omega_jewelry_store_sanitize_checkbox',
    )
);
$wp_customize->add_control('omega_jewelry_store_theme_loader',
    array(
        'label' => esc_html__('Enable Preloader', 'omega-jewelry-store'),
        'section' => 'omega_jewelry_store_button_header_setting',
        'type' => 'checkbox',
    )
);