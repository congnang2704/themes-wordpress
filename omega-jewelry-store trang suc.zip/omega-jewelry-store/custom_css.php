<?php

$omega_jewelry_store_custom_css = "";

        $omega_jewelry_store_theme_pagination_options_alignment = get_theme_mod('omega_jewelry_store_theme_pagination_options_alignment', 'Center');
		if ($omega_jewelry_store_theme_pagination_options_alignment == 'Center') {
		    $omega_jewelry_store_custom_css .= '.pagination{';
		    $omega_jewelry_store_custom_css .= 'text-align: center;';
		    $omega_jewelry_store_custom_css .= '}';
		} else if ($omega_jewelry_store_theme_pagination_options_alignment == 'Right') {
		    $omega_jewelry_store_custom_css .= '.pagination{';
		    $omega_jewelry_store_custom_css .= 'text-align: Right;';
		    $omega_jewelry_store_custom_css .= '}';
		} else if ($omega_jewelry_store_theme_pagination_options_alignment == 'Left') {
		    $omega_jewelry_store_custom_css .= '.pagination{';
		    $omega_jewelry_store_custom_css .= 'text-align: Left;';
		    $omega_jewelry_store_custom_css .= '}';
		}

	$omega_jewelry_store_theme_breadcrumb_options_alignment = get_theme_mod('omega_jewelry_store_theme_breadcrumb_options_alignment', 'Center');
		if ($omega_jewelry_store_theme_breadcrumb_options_alignment == 'Center') {
		    $omega_jewelry_store_custom_css .= '.breadcrumbs ul{';
		    $omega_jewelry_store_custom_css .= 'text-align: center !important;';
		    $omega_jewelry_store_custom_css .= '}';
		} else if ($omega_jewelry_store_theme_breadcrumb_options_alignment == 'Right') {
		    $omega_jewelry_store_custom_css .= '.breadcrumbs ul{';
		    $omega_jewelry_store_custom_css .= 'text-align: Right !important;';
		    $omega_jewelry_store_custom_css .= '}';
		} else if ($omega_jewelry_store_theme_breadcrumb_options_alignment == 'Left') {
		    $omega_jewelry_store_custom_css .= '.breadcrumbs ul{';
		    $omega_jewelry_store_custom_css .= 'text-align: Left !important;';
		    $omega_jewelry_store_custom_css .= '}';
		}